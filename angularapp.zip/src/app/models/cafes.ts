
export interface CafesInterface {
    nombre?: string;
    tipo?: string;
    descripcion?: string;
    existencia?:string;
    imagen?: string;
    precio?: string;
    link_facebook?: string;
    ventas?: string;
    oferta?: string;
    id?: string;
    userUid?: string;
  }