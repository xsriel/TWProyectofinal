export interface ContactoModelo {
    email: string;
    fullname: string;
    comment: string;
}
