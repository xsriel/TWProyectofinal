import { Component, OnInit } from '@angular/core';
import {DataApiService} from '../../services/data-api.service';
import Swal  from 'sweetalert2';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
bandera:boolean;
  constructor(private dataApi:DataApiService) { }
public productos=[];
public producto='';
datos:any={};

  ngOnInit(){
    this.bandera=true;
    this.dataApi.getAllProductos().subscribe(productos=>{
      
      console.log('productos', productos);
      this.productos=productos;
      this.bandera=false;
      this.enviar();
      
    })
    
  }
  enviar():void{
    let urlapi=`https://ejemplohosting-e20bb.web.app/getItems`;
    console.log(urlapi);
    this.dataApi.getJason(urlapi).subscribe((data:any)=>{
      //this.loadingbusqueda=true;
      //this.datos=data['state'];
      this.datos=data;
     // this.datos=Array.of(this.datos);
        console.log(data);
        Swal.fire({
          title: 'HOLA!',
          text: data[0].items,
          imageUrl: 'https://unsplash.it/400/200',
          imageWidth: 400,
          imageHeight: 200,
          imageAlt: 'Custom image',
          showConfirmButton: false,
          timer: 3000,
        })
        console.log(this.datos);
    });
  }


}
