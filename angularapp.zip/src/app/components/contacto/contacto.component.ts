import { Component, OnInit } from '@angular/core';
import {DataApiService} from '../../services/data-api.service';
import Swal  from 'sweetalert2'
@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {
  datos1:any={};
  constructor(private dataApi:DataApiService) { }

  ngOnInit(): void {
    this.propia();
  }
  propia(){
    Swal.fire({
      title: 'NO OLVIDES LOGUEARTE PARA VER LASS OFERTAS QUE TE TENEMOS',
      showClass: {
        popup: 'animate__animated animate__fadeInDown'
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutUp'
      }
    })
    
    let urlapi2=`https://ejemplohosting-e20bb.web.app/api`;
    this.dataApi.getJason(urlapi2).subscribe((data:any)=>{
     this. datos1=data;
  
    });
  }
}
