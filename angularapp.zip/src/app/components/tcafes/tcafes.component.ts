import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tcafes',
  templateUrl: './tcafes.component.html',
  styleUrls: ['./tcafes.component.css']
})
export class TcafesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
