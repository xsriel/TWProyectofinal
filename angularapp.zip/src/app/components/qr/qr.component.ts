import { NgxQRCodeModule } from 'ngx-qrcode2';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qr',
  templateUrl: './qr.component.html',
  styleUrls: ['./qr.component.css']
})
export class QRComponent implements OnInit {

  historia = 'https://cursosbaristacafe.com.mx/blog/historia-del-cafe/';
  video = 'https://www.youtube.com/watch?v=BoAAgoqxsxI';

  /*private generateNumber(pedido: number) {
    return Math.floor((Math.random() * (pedido < 2 ? 100 : 1000)) + 1);
  }*/
  constructor() { }

  ngOnInit() {
  }

}
