import { Component, OnInit } from '@angular/core';
import { SpeechService } from '../../servicios/speech.service';
@Component({
  selector: 'app-acercade',
  templateUrl: './acercade.component.html',
  styleUrls: ['./acercade.component.css']
})
export class AcercadeComponent implements OnInit {
  title = 'pruebaSpeak-TTS';
  index: number;
  v: number = this.getVolume();
  speechData: any;

  constructor(private spk: SpeechService) {
    console.log('constructor');
   }

  ngOnInit(): void {
    
    
  }
  

  start(html){
    this.spk.start(html); 
  }
  pause(){
    this.spk.pause();
  }
  resume(){
    this.spk.resume();
  }

  getSpeechData(){    
    this.speechData = this.spk.speechData;
    console.log(this.speechData);
  }

  setVolume(v){
    this.spk.setVolume(v);
  }

  getVolume(){
    return this.spk.getVolume();
  }

  setLanguage(lang){
    this.spk.setLanguage(lang);
  }
}
