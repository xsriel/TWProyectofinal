import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carritocompras',
  templateUrl: './carritocompras.component.html',
  styleUrls: ['./carritocompras.component.css']
})
export class CarritocomprasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
