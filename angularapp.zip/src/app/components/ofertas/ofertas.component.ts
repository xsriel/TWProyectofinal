import { Component, OnInit } from '@angular/core';
import { DataApiService } from '../../services/data-api.service';
import { CafesInterface } from '../../models/cafes';
import { ActivatedRoute, Params} from '@angular/router';

@Component({
  selector: 'app-ofertas',
  templateUrl: './ofertas.component.html',
  styleUrls: ['./ofertas.component.css']
})
export class OfertasComponent implements OnInit {

  constructor(private dataApi: DataApiService, private route: ActivatedRoute) { }
  public productos: CafesInterface[];
  ngOnInit(): void {
    this.getOffers();
   // let bproducto= this.route.snapshot.params['producto'];
  // this.getbuscarproducto(bproducto);
    console.log('OFERTAS', this.productos);
    //console.log(bproducto);
  }
  getOffers() {
    this.dataApi.getAllProductosOffers().subscribe(offers => this.productos = offers);
  }

/*  getbuscarproducto(bproducto:string){
      this.dataApi.getAllProductosOffersproducto(bproducto).subscribe(bproducto =>this.productos=bproducto);

  }*/
}
