import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preguntasfrecuentes',
  templateUrl: './preguntasfrecuentes.component.html',
  styleUrls: ['./preguntasfrecuentes.component.css']
})
export class PreguntasfrecuentesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
