// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig:{
    apiKey: "AIzaSyArQ4IC5hrciVNTxlhVVNei0u7wekKV6YE",
    authDomain: "cafexhito.firebaseapp.com",
    databaseURL: "https://cafexhito.firebaseio.com",
    projectId: "cafexhito",
    storageBucket: "cafexhito.appspot.com",
    messagingSenderId: "898883616577",
    appId: "1:898883616577:web:ed7074e1d448cb6ac12bc0",
    measurementId: "G-7Z3L47GEEK"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
