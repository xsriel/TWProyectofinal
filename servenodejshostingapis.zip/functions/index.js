const functions = require('firebase-functions');
const express = require('express')
const cors = require('cors')({ origin: true });
const admin = require('firebase-admin');
admin.initializeApp();
var request 	= require("request");
const database = admin.database().ref('/items');
//API mia 
const app = express()
app.get('*', (req, res) => {
  res.send("Hola eres administrador")
})
///api mia
exports.getItems = functions.https.onRequest((req, res) => {
  return cors(req, res.send("NO OLVIDES LOGUEARTE PARA VER LAS OFERTAS QUE TE TENEMOS"), () => {
    if(req.method !== 'GET') {
      return res.status(404).json({
        message: 'Not allowed'
      })
    }

    let items = [];

    return database.on('value', (snapshot) => {
      snapshot.forEach((item) => {
        items.push({
          id: item.key,
          items: item.val().item
        });
      });
      
      res.status(200).json(items)
    }, (error) => {
      res.status(error.code).json({
        message: `Something went wrong. ${error.message}`
      })
    })
  })
})


//
app.get('*',(req,res)=>{
})
exports.api = functions.https.onRequest(app)
// // Create and Deploy Your First Cloud Functions
 //https:firebase.google.com/docs/functions/write-firebase-functions
//API a base de datos Cloud Firestore metodo PUT

exports.addItem = functions.https.onRequest((req, res) => {
  return cors(req, res, () => {
    if(req.method !== 'POST') {
      return res.status(401).json({
        message: 'Not allowed'
      })
    }
    console.log(req.body)
  
    const item = req.body.item

    database.push({ item });

    let items = [];

    return database.on('value', (snapshot) => {
      snapshot.forEach((item) => {
        items.push({
          id: item.key,
          items: item.val().item
        });
      });
      
      res.status(200).json(items)
    }, (error) => {
      res.status(error.code).json({
        message: `Something went wrong. ${error.message}`
      })
    })
  })
})
//API a base de datos Cloud Firestore metodo GET

exports.getItems = functions.https.onRequest((req, res) => {
  return cors(req, res, () => {
    if(req.method !== 'GET') {
      return res.status(404).json({
        message: 'Not allowed'
      })
    }

    let items = [];

    return database.on('value', (snapshot) => {
      snapshot.forEach((item) => {
        items.push({
          id: item.key,
          items: item.val().item
        });
      });
      
      res.status(200).json(items)
    }, (error) => {
      res.status(error.code).json({
        message: `Something went wrong. ${error.message}`
      })
    })
  })
})


//API mia tambien
exports.helloWorld = functions.https.onRequest((request, response) => {
  response.json({
    message: 'Hello from Firebase!',
  });
});


exports.helloWorld = functions.https.onRequest((request, response) => {
  //response.send("Hello from Firebase!");
  response.json({ mensaje: '¡A beber cerveza!' })  ;
  

  
 });